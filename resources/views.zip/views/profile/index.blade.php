@extends('layouts.profile')

@section('content')
    <h1>hi</h1>
@endsection

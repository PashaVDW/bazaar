<a href="/">
    <img src="{{ asset('images/DeBazaarLogo.png') }}" {{ $attributes->merge(['class' => '']) }} alt="De Bazaar Logo">
</a>

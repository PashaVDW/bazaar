<!DOCTYPE html>
<html lang="en">
<head>
  <x-shared.head />
</head>
<body class="bg-gray-100 p-4">
    @yield('content')
</body>
</html>
